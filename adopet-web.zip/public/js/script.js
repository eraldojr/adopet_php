function logout(){
  if(isset($_POST['logout']));
}

function setChangePass(){
  document.getElementById('changePass').value = "true";
}
