The Adopet Project.

Hi! This is the Adopet project. This project was created to be a plataform for announce animals for adoption. Developed under an academic environment we have the purpose to  offer a quality and free service for people find a pet to adopt, care and love. All codes will be available.

Olá! Este é o projeto Adopet. Este projeto foi criado para proporcionar uma plataforma para o anúncio de animais para adoção. Desenvolvido em ambiente acadêmico, temos o objetivo de oferecer um serviço gratuito e de qualidade para que as pessoas possam encontrar um pet para adotar, cuidar e amar. Todo o código fonte será disponibilizado.