<div class="container-fluid">
  <div class="row">
    <div class="col-md-12 text-center block-center">
      <h1>Oh, não! Estamos num mato sem cachorro</h1>
      <h4>Tente voltar à página anterior. Caso o erro persista entre em contato conosco.</h4>
      <img src="/img/404-bush.png" alt="Erro 404" class="img-responsive center-block">
    </div>
  </div>
</div>
