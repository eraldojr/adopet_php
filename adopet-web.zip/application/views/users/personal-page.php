<?php
 ?>

 <div class="container-fluid">
   <div class="row text-center">
     <div class="col-md-3">
       <a href="/meus-pets"><h3>Meus Pets</h3></a>
     </div>
     <div class="col-md-3">
       <a href="/novo-pet"><h3>Cadastrar Pet</h3></a>
     </div>
     <div class="col-md-3">
       <a href="/meus-dados"><h3>Meus Dados</h3></a>
     </div>

     <div class="col-md-3">
       <a href="#"><h3>...</h3></a>
     </div>
   </div>


 </div>
