<div class="row">
  <div class="col-md-12 text-center block-center">
    <h1>SEJA BEM VINDO!</h1>
    <h4>Em breve nós te ajudaremos a encontrar um novo amigo.</h4>
  </div>
</div>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-12 text-center block-center">
      <img src="/img/Logo-Adopet-1080x1920.png" alt="Logo Adopet" width="50%">
    </div>
  </div>
</div>
