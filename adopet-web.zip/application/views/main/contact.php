<div class="row">
  <div class="col-md-12 text-center block-center">
    <h1>CONTATO</h1>
  </div>
</div>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-12 text-center block-center">
      <img src="/img/Logo-Adopet-1080x1920.png" alt="Logo Adopet" width="50%">
    </div>
  </div>
</div>
